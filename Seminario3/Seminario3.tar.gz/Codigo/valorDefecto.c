#include <stdio.h>
#include <stdlib.h>

#ifdef _OPENMP
    #include <omp.h>
#else
    #define omp_get_thread_num() 0
#endif

/*
 * Aqui runtime depende de la var run-shed-var va con el tiempo de ej
 * Aqui introduces solo las iteraciones el chuck puede ser static, dynamic o guided
 *
 * export OMP_SHEDULE="static,2" por ej
 *
 */

int main(int argc, char **argv)
{
    int i, n=20,  a[n], suma=0;
    int modifier;
    omp_sched_t kind;
    
    omp_get_schedule(&kind,&modifier);
       
    if(argc < 2)
    {
        fprintf(stderr,"\nFalta el tamaño de chunk\n");
        exit(-1);
    }

    n = atoi(argv[1]); if(n>20) n= 20; 

    for (i=0; i<n; i++)
        a[i] = i;
 
    #pragma omp parallel for firstprivate(suma) \
                lastprivate(suma) schedule(runtime)
    for (i=0; i<n; i++)
    {
        suma = suma + a[i];
        printf(" thread %d suma a[%d]=%d suma=%d \n",
             omp_get_thread_num(),i,a[i],suma);
    } 

    printf("Fuera de 'parallel for' suma=%d\n",suma);
    printf("Valores por defecto: %d ºel chunk: %d \n", kind, modifier);
}

